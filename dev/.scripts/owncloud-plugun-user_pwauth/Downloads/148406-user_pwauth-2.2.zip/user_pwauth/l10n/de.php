<?php
/*
            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.

*/

/*
 * Thanks to Manuel for proofreading.
 */

$TRANSLATIONS = Array(
	"pwauth_path" => "Pfad zu pwauth",
	"uid_list" => "Liste der autorisierten UIDs",
	"uid_list_original-title" => "Durch ';' getrennt oder einen UID-Bereich durch '-' getrennt zum Beispiel 1000-1003;1005"
);

?>
