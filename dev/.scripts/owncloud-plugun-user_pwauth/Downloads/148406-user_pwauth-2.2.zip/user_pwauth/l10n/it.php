<?php

$TRANSLATIONS = Array(
	"pwauth_path" => "Percorso di pwauth",
	"uid_list" => "Elenco degli UIDs autorizzati",
	"uid_list_original-title" => "Separati da ';' o un intervallo di UIDs separato da '-' per esempio 1000-1003;1005"
);

?>
